<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal7d77bb759cf09fb7609ab7d50dcb0764 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7d77bb759cf09fb7609ab7d50dcb0764 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sections.hero','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7d77bb759cf09fb7609ab7d50dcb0764)): ?>
<?php $attributes = $__attributesOriginal7d77bb759cf09fb7609ab7d50dcb0764; ?>
<?php unset($__attributesOriginal7d77bb759cf09fb7609ab7d50dcb0764); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7d77bb759cf09fb7609ab7d50dcb0764)): ?>
<?php $component = $__componentOriginal7d77bb759cf09fb7609ab7d50dcb0764; ?>
<?php unset($__componentOriginal7d77bb759cf09fb7609ab7d50dcb0764); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf7639b4297590aab4e2fa9c6ac29c451 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf7639b4297590aab4e2fa9c6ac29c451 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sections.about','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.about'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf7639b4297590aab4e2fa9c6ac29c451)): ?>
<?php $attributes = $__attributesOriginalf7639b4297590aab4e2fa9c6ac29c451; ?>
<?php unset($__attributesOriginalf7639b4297590aab4e2fa9c6ac29c451); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf7639b4297590aab4e2fa9c6ac29c451)): ?>
<?php $component = $__componentOriginalf7639b4297590aab4e2fa9c6ac29c451; ?>
<?php unset($__componentOriginalf7639b4297590aab4e2fa9c6ac29c451); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal3c60356ca7bfc9a60eb5905961d180db = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3c60356ca7bfc9a60eb5905961d180db = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sections.services','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.services'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3c60356ca7bfc9a60eb5905961d180db)): ?>
<?php $attributes = $__attributesOriginal3c60356ca7bfc9a60eb5905961d180db; ?>
<?php unset($__attributesOriginal3c60356ca7bfc9a60eb5905961d180db); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3c60356ca7bfc9a60eb5905961d180db)): ?>
<?php $component = $__componentOriginal3c60356ca7bfc9a60eb5905961d180db; ?>
<?php unset($__componentOriginal3c60356ca7bfc9a60eb5905961d180db); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal7f4a738740168d1fdbd9f2c52859a0fb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7f4a738740168d1fdbd9f2c52859a0fb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sections.process','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.process'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7f4a738740168d1fdbd9f2c52859a0fb)): ?>
<?php $attributes = $__attributesOriginal7f4a738740168d1fdbd9f2c52859a0fb; ?>
<?php unset($__attributesOriginal7f4a738740168d1fdbd9f2c52859a0fb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f4a738740168d1fdbd9f2c52859a0fb)): ?>
<?php $component = $__componentOriginal7f4a738740168d1fdbd9f2c52859a0fb; ?>
<?php unset($__componentOriginal7f4a738740168d1fdbd9f2c52859a0fb); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalf930a044f77874b6f56ba7764c421c73 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf930a044f77874b6f56ba7764c421c73 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sections.why-us','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.why-us'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf930a044f77874b6f56ba7764c421c73)): ?>
<?php $attributes = $__attributesOriginalf930a044f77874b6f56ba7764c421c73; ?>
<?php unset($__attributesOriginalf930a044f77874b6f56ba7764c421c73); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf930a044f77874b6f56ba7764c421c73)): ?>
<?php $component = $__componentOriginalf930a044f77874b6f56ba7764c421c73; ?>
<?php unset($__componentOriginalf930a044f77874b6f56ba7764c421c73); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal62de9fc3ebe431a0d746cd50eda6c97f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal62de9fc3ebe431a0d746cd50eda6c97f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sections.contact','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.contact'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal62de9fc3ebe431a0d746cd50eda6c97f)): ?>
<?php $attributes = $__attributesOriginal62de9fc3ebe431a0d746cd50eda6c97f; ?>
<?php unset($__attributesOriginal62de9fc3ebe431a0d746cd50eda6c97f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal62de9fc3ebe431a0d746cd50eda6c97f)): ?>
<?php $component = $__componentOriginal62de9fc3ebe431a0d746cd50eda6c97f; ?>
<?php unset($__componentOriginal62de9fc3ebe431a0d746cd50eda6c97f); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mifta/projects/php/nice-tech/resources/views/welcome.blade.php ENDPATH**/ ?>