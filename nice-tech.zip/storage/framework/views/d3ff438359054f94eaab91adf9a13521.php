
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['uid' => 'zt', 'tone' => 'dark']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['uid' => 'zt', 'tone' => 'dark']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $zeyla = $tone === 'light' ? 'text-ink' : 'text-white';
    $tech  = $tone === 'light' ? 'text-brand-teal-dark' : 'text-brand-teal-light';
?>

<span <?php echo e($attributes->merge(['class' => 'inline-flex items-center gap-3'])); ?>>
    <svg class="size-9 shrink-0" viewBox="0 0 40 40" fill="none" aria-hidden="true">
        <defs>
            <linearGradient id="<?php echo e($uid); ?>-g" x1="3" y1="2" x2="37" y2="38" gradientUnits="userSpaceOnUse">
                <stop stop-color="#19b6bc"/>
                <stop offset="1" stop-color="#05626a"/>
            </linearGradient>
        </defs>
        <rect width="40" height="40" rx="11" fill="url(#<?php echo e($uid); ?>-g)"/>
        <rect x=".5" y=".5" width="39" height="39" rx="10.5" stroke="#fff" stroke-opacity=".22"/>
        <path d="M12.5 13.5H27.5L12.5 26.5H24" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
        <circle cx="28.5" cy="26.5" r="2.1" stroke="#a5f0f3" stroke-width="1.8"/>
    </svg>
    <span class="font-display text-[1.3rem] font-semibold leading-none tracking-tight <?php echo e($zeyla); ?>">Zeyla<span class="<?php echo e($tech); ?> font-medium"> Tech</span></span>
</span>
<?php /**PATH /home/mifta/projects/php/nice-tech/resources/views/components/logo.blade.php ENDPATH**/ ?>