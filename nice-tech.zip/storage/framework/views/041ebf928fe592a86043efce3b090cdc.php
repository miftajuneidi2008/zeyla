<section id="process" class="scroll-mt-24 bg-white py-24 lg:py-32">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

        <div class="max-w-2xl">
            <p class="eyebrow">How we work</p>
            <h2 class="mt-5 font-display text-4xl font-semibold tracking-[-0.03em] text-ink sm:text-5xl">Our <span class="accent text-brand-teal-dark">process</span></h2>
            <p class="mt-5 text-lg leading-relaxed text-slate-600">
                Five steps, from the first conversation to long-term support.
            </p>
        </div>

        <div data-process class="process relative mt-20">

            
            <div class="absolute bottom-24 left-7 top-7 w-px bg-slate-200 md:bottom-auto md:left-[10%] md:right-[10%] md:h-px md:w-auto" aria-hidden="true">
                <div data-process-fill class="h-full w-full bg-linear-to-r from-brand-teal to-brand-teal-light"></div>
            </div>

            <ol class="relative md:grid md:grid-cols-5 md:gap-6">
                <?php $__currentLoopData = config('zeyla.steps'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-step class="process-step relative flex gap-5 pb-10 last:pb-0 md:flex-col md:items-center md:gap-0 md:pb-0 md:text-center">
                        <span class="step-badge relative z-10 grid size-14 shrink-0 place-items-center rounded-full">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $step['icon']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($step['icon'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </span>
                        <div class="md:mt-7">
                            <p class="text-xs font-medium uppercase tracking-[0.16em] text-brand-teal-dark">Step <?php echo e($loop->iteration); ?></p>
                            <h3 class="mt-2 font-display text-xl font-semibold tracking-tight text-ink"><?php echo e($step['title']); ?></h3>
                            <p class="mt-2 leading-relaxed text-slate-600 md:mx-auto md:max-w-[15rem]"><?php echo e($step['description']); ?></p>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </div>
    </div>
</section>
<?php /**PATH /home/mifta/projects/php/nice-tech/resources/views/components/sections/process.blade.php ENDPATH**/ ?>