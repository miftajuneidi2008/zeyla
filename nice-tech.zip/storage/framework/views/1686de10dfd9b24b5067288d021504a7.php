<?php
    // type => [ring/accent colour, icon, icon colour]
    $styles = [
        'success' => ['ring-brand-teal-light/40', 'check', 'bg-brand-teal text-white'],
        'error'   => ['ring-red-400/50',          'alert', 'bg-red-500 text-white'],
        'warning' => ['ring-amber-300/50',        'alert', 'bg-amber-400 text-ink'],
        'info'    => ['ring-white/20',            'info',  'bg-white/15 text-white'],
    ];

    $messages = collect($styles)
        ->keys()
        ->filter(fn ($type) => session()->has($type))
        ->mapWithKeys(fn ($type) => [$type => session($type)]);
?>

<?php if($messages->isNotEmpty()): ?>
    <div class="pointer-events-none fixed inset-x-0 top-24 z-50 flex flex-col items-center gap-3 px-4">
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php [$ring, $icon, $badge] = $styles[$type]; ?>
            <div data-flash="<?php echo e($type); ?>"
                 role="<?php echo e($type === 'error' ? 'alert' : 'status'); ?>"
                 class="pointer-events-auto flex w-full max-w-md items-start gap-4 rounded-2xl bg-ink/95 py-4 pl-4 pr-5 text-white shadow-2xl shadow-black/40 ring-1 backdrop-blur-xl <?php echo e($ring); ?>">
                <span class="mt-0.5 grid size-7 shrink-0 place-items-center rounded-full <?php echo e($badge); ?>" aria-hidden="true">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $icon,'class' => 'size-4 stroke-[2.2]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon),'class' => 'size-4 stroke-[2.2]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </span>
                <p class="flex-1 pt-0.5 leading-relaxed"><?php echo e($message); ?></p>
                <button type="button" data-flash-close aria-label="Dismiss message"
                        class="-mr-1 grid size-6 shrink-0 place-items-center rounded-full text-xl leading-none text-slate-400 transition-colors hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-white">
                    &times;
                </button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php /**PATH /home/mifta/projects/php/nice-tech/resources/views/components/flash.blade.php ENDPATH**/ ?>