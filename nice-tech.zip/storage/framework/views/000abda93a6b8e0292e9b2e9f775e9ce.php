<div class="px-3 sm:px-5">
<section id="why-us" class="frame scroll-mt-24 overflow-hidden bg-linear-to-br from-sky-50 via-white to-blue-50 py-20 ring-1 ring-slate-900/[0.07] lg:py-28">
    <div class="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

        <div data-why-head>
            <p class="eyebrow">Why <?php echo e(config('zeyla.name')); ?></p>
            <h2 class="mt-5 max-w-2xl font-display text-4xl font-semibold tracking-[-0.03em] text-ink sm:text-5xl">
                Why clients <span class="accent text-brand-red">choose us</span>
            </h2>
        </div>
        <div data-why-rule class="mt-7 h-px w-24 bg-linear-to-r from-brand-teal to-transparent"></div>

        
        <dl class="mt-14 grid gap-px overflow-hidden rounded-3xl bg-slate-900/[0.07] ring-1 ring-slate-900/[0.07] sm:grid-cols-2">
            <?php $__currentLoopData = config('zeyla.reasons'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div data-why-item class="why-card group bg-white/70 p-8 lg:p-12">
                    <div class="flex items-start justify-between">
                        <span data-why-icon class="grid size-12 place-items-center rounded-2xl bg-brand-teal/10 text-brand-teal-dark ring-1 ring-brand-teal/15 transition duration-500 ease-out group-hover:-translate-y-1 group-hover:bg-brand-teal group-hover:text-white group-hover:ring-transparent">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => $reason['icon']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($reason['icon'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </span>
                        <span class="font-display text-sm font-medium tabular-nums text-slate-300" aria-hidden="true"><?php echo e(sprintf('%02d', $loop->iteration)); ?></span>
                    </div>
                    <dt class="mt-8 font-display text-2xl font-semibold tracking-tight text-ink"><?php echo e($reason['title']); ?></dt>
                    <dd class="mt-3 max-w-sm leading-relaxed text-slate-600"><?php echo e($reason['description']); ?></dd>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </dl>
    </div>
</section>
</div>
<?php /**PATH /home/mifta/projects/php/nice-tech/resources/views/components/sections/why-us.blade.php ENDPATH**/ ?>