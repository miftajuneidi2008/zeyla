<?php
    $site = config('zeyla');
    $home = url('/');
    $tel = fn (string $p) => '+251' . ltrim($p, '0');

    $explore = [
        ['Services',               $home . '#services'],
        ['Our process',            $home . '#process'],
        ['Why ' . $site['name'],   $home . '#why-us'],
        ['Contact',                $home . '#contact'],
    ];

    $head = 'text-xs font-medium uppercase tracking-[0.16em] text-slate-400';
    $link = 'text-slate-300 transition-colors hover:text-white focus:outline-none focus-visible:text-white';
?>

<div class="p-3 sm:p-5">
<footer class="frame relative isolate overflow-hidden bg-ink text-sm ring-1 ring-white/10">
    <div class="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(36rem_22rem_at_8%_0%,rgba(11,143,148,0.16),transparent_65%)]" aria-hidden="true"></div>
    <div class="mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 lg:grid-cols-12 lg:gap-8 lg:px-8 lg:py-20">

        <div class="lg:col-span-4">
            <a href="<?php echo e($home); ?>" class="inline-block rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-teal-light" aria-label="<?php echo e($site['name']); ?> home">
                <?php if (isset($component)) { $__componentOriginal987d96ec78ed1cf75b349e2e5981978f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo','data' => ['uid' => 'foot']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['uid' => 'foot']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $attributes = $__attributesOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__attributesOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f)): ?>
<?php $component = $__componentOriginal987d96ec78ed1cf75b349e2e5981978f; ?>
<?php unset($__componentOriginal987d96ec78ed1cf75b349e2e5981978f); ?>
<?php endif; ?>
            </a>
            <p class="mt-6 max-w-xs text-base leading-relaxed text-slate-400">
                <?php echo e($site['tagline']); ?> for government, NGOs, and private institutions.
            </p>
        </div>

        <nav aria-label="Footer" class="lg:col-span-2">
            <p class="<?php echo e($head); ?>">Explore</p>
            <ul class="mt-5 space-y-3">
                <?php $__currentLoopData = $explore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $href]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e($href); ?>" class="<?php echo e($link); ?>"><?php echo e($label); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </nav>

        <div class="lg:col-span-3">
            <p class="<?php echo e($head); ?>">Services</p>
            <ul class="mt-5 space-y-3">
                <?php $__currentLoopData = $site['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e($home); ?>#service-<?php echo e($service['slug']); ?>" class="<?php echo e($link); ?>"><?php echo e($service['name']); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>


        <div class="lg:col-span-3">
            <p class="<?php echo e($head); ?>">Get in touch</p>
            <ul class="mt-5 space-y-3">
                <li><a href="mailto:<?php echo e($site['email']); ?>" class="break-all <?php echo e($link); ?>"><?php echo e($site['email']); ?></a></li>
                <?php $__currentLoopData = array_slice($site['phones'], 0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="tel:<?php echo e($tel($phone)); ?>" class="<?php echo e($link); ?>"><?php echo e($phone); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    <div class="border-t border-white/10">
        <div class="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-6 text-slate-400 sm:px-6 md:flex-row md:items-center md:justify-between lg:px-8">
            <p>&copy; <?php echo e(date('Y')); ?> <?php echo e($site['name']); ?>. All rights reserved.</p>
            <p><?php echo e($site['address']); ?></p>
            <a href="#home" class="group inline-flex items-center gap-2 <?php echo e($link); ?>">
                Back to top
                <span class="grid size-8 place-items-center rounded-full border border-white/15 transition-colors group-hover:border-white/40" aria-hidden="true">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-up','class' => 'size-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-up','class' => 'size-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </span>
            </a>
        </div>
    </div>
</footer>
</div>
<?php /**PATH /home/mifta/projects/php/nice-tech/resources/views/components/footer.blade.php ENDPATH**/ ?>